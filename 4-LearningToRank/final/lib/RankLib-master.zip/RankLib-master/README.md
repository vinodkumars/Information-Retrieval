RankLib
=======

A Learning to Rank Library. Copied from: http://people.cs.umass.edu/~vdang/ranklib.html